package com.product.Details.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.product.Details.entity.Details;

public interface DetailsRepo extends JpaRepository<Details, Integer> {

}
