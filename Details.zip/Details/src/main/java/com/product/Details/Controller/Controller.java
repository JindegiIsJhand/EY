package com.product.Details.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.product.Details.Repo.DetailsRepo;
import com.product.Details.entity.Details;

@RestController
public class Controller {
	
	
	@Autowired
	DetailsRepo repo;
	
	@RequestMapping("/{id}")
	public Details search(@PathVariable("id")int id )
	{
		System.out.println("Hii");
		Details details=repo.findById(id).orElse(null);
		return details;
	}
	

}
