package com.product.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.product.Entity.Product;

public interface ProductRepo extends JpaRepository<Product, Integer> {
	Product findBytype(String type);

}
