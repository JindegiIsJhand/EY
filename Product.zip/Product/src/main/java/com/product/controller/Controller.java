package com.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.product.Entity.Couple;
import com.product.Entity.Details;
import com.product.Entity.Product;
import com.product.Repo.ProductRepo;


@RestController
public class Controller {
	
	@Autowired
	ProductRepo repo;
	
	@Autowired
	RestTemplate restTemplate;
	@RequestMapping("/{id}")
	public Product searchbyID(@PathVariable("id")int id)
	{
		Product product=repo.findById(id).orElse(null);
		return product;
	}
	
	@RequestMapping("/type/{type}")
	public Product searchbyType(@PathVariable("type")String type)
	{
		Product product=repo.findBytype(type);
		return  product;
	}
	
	@RequestMapping("/Details/{id}")
	public Couple detailsbyID(@PathVariable("id")int id)
	{
		Product product=repo.findById(id).orElse(null);		
		Details details=restTemplate.getForObject("http://localhost:9002/"+id,Details.class);
		Couple couple=new Couple();
		couple.setDetails(details);
		couple.setProduct(product);
		
		return couple;
	}
	
	//http://localhost:9002/1

}
